const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
admin.initializeApp();

const ANTHROPIC_API_KEY = defineSecret('ANTHROPIC_API_KEY');
const DAILY_LIMIT = 40;          // AI requests per user per day
const MODEL = 'claude-haiku-4-5'; // $1 / $5 per million tokens

exports.aiComplete = onCall(
  { secrets: [ANTHROPIC_API_KEY], region: 'us-central1', maxInstances: 10, timeoutSeconds: 60 },
  async (req) => {
    if (!req.auth) throw new HttpsError('unauthenticated', 'Sign in to use AI.');
    const prompt = String((req.data && req.data.prompt) || '').slice(0, 12000);
    if (!prompt) throw new HttpsError('invalid-argument', 'Empty prompt.');

    const day = new Date().toISOString().slice(0, 10);
    const ref = admin.firestore().doc(`aiUsage/${req.auth.uid}_${day}`);
    await admin.firestore().runTransaction(async (t) => {
      const snap = await t.get(ref);
      const count = (snap.exists ? snap.data().count : 0) + 1;
      if (count > DAILY_LIMIT) throw new HttpsError('resource-exhausted', 'Daily AI limit reached.');
      t.set(ref, { uid: req.auth.uid, day, count }, { merge: true });
    });

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY.value(),
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 2000, messages: [{ role: 'user', content: prompt }] })
    });
    if (!res.ok) throw new HttpsError('internal', 'AI service error ' + res.status);
    const data = await res.json();
    return { text: (data.content && data.content[0] && data.content[0].text) || '' };
  }
);
