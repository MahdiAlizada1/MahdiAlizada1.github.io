# Turn on built-in AI (users don't need their own key)

One-time setup, about 15 minutes.

1. Get an API key at https://console.anthropic.com → API Keys. Add $10 credit and set a monthly spend limit (Settings → Limits).
2. In the Firebase console (project rivo-planner) → upgrade to the **Blaze** (pay-as-you-go) plan. Set a budget alert at e.g. $10.
3. Install Node.js 20 from https://nodejs.org, then in a terminal:

```
npm install -g firebase-tools
firebase login
cd deploy
firebase use rivo-planner
cd functions && npm install && cd ..
firebase functions:secrets:set ANTHROPIC_API_KEY     (paste your key)
firebase deploy --only functions,firestore:rules
```

4. Upload the new index.html and sw.js to GitHub. Done — every Google-signed-in user now gets AI automatically.

Daily limit per user: change DAILY_LIMIT in functions/index.js (default 40), then redeploy.
